package br.edu.up.repository;

import org.springframework.data.repository.CrudRepository;

import br.edu.up.dominio.Modulo;



public interface ModuloRepository extends CrudRepository<Modulo, Integer> {


}
