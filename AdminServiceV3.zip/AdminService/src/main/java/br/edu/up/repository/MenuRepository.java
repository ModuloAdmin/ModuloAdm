package br.edu.up.repository;

import org.springframework.data.repository.CrudRepository;

import br.edu.up.dominio.Menu;

public interface MenuRepository extends CrudRepository<Menu, Integer> {


}
